This is the source code for the Thrifty Antenna Sweeper
Copyright 2013 Beric Dunn
Creative Commons Attribution-ShareAlike 3.0 Unported


It was written in Microsoft Visual Basic 2012

The "Express" version of Visual Studio is available from Microsoft:

http://www.microsoft.com/visualstudio/eng/products/visual-studio-express-for-windows-desktop